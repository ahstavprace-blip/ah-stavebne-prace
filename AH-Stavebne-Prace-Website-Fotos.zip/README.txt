# AH Stavebne Prace – Website

Enthält:
- index.html
- images/ – Fotos der ausgeführten Arbeiten

Die Website enthält die Angaben aus der Visitenkarte und eine Galerie mit den hochgeladenen Fotos.

Nicht enthalten: „Abrechnung alle 14 Tage“.
